package SUBCLASES_CARLOS;

import CLASEMAYOR.EMPLEADOS;

public class DISEÑO extends EMPLEADOS{
    private int Programas;  //Declaración atributo de clase hija
    
    //Constructor clase hija 'Diseñador'

    public DISEÑO(int Programas, String nombre, int edad, String proyectoAsignado, double salario, String departamento) {
        super(nombre, edad, proyectoAsignado, salario, departamento);
        this.Programas = Programas;
    }


    public int getProgramas() {
        return Programas;
    }

    @Override
    public double CalcularSalario() {//Sobreescritura del método CalcularSalario() de la clase 'Empleados'
        return sueldoBase = 360;
        }
    
    public int Adicional() {
        return Programas = 5;
        }

    @Override
    public String toString() {
        return Programas + " Programas de diseño";
    }
}
package CLASEMAYOR;

public abstract class EMPLEADOS{                                          
    private String nombre;
    private int edad;
    private String proyectoAsignado;
    protected double sueldoBase;
    private String departamento;


    public EMPLEADOS(String nombre, int edad, String proyectoAsignado, double salario, String departamento) {
        this.nombre = nombre;
        this.edad = edad;
        this.proyectoAsignado = proyectoAsignado;
        this.sueldoBase = salario;
        this.departamento = departamento;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getProyectoAsignado() {
        return proyectoAsignado;
    }

    public void setProyectoAsignado(String proyectoAsignado) {
        this.proyectoAsignado = proyectoAsignado;
    }

    public double getSalario() {
        return sueldoBase;
    }

    public void setSalario(double salario) {
        this.sueldoBase = salario;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }
    
    public abstract double CalcularSalario();                                   
    
}


package SUBCLASES_CARLOS;

import CLASEMAYOR.EMPLEADOS;

public class ANALISTA extends EMPLEADOS{
    private int nivelExperiencia;        //Declaración atributo de clase hija
    
    

    public ANALISTA(int nivelExperiencia, String nombre, int edad, String proyectoAsignado, double salario, String departamento) {
        super(nombre, edad, proyectoAsignado, salario, departamento);
        this.nivelExperiencia = nivelExperiencia;
    }


    public int getNivelExperiencia() {
        return nivelExperiencia;
    }

    @Override
    public double CalcularSalario() {  //Sobreescritura del método CalcularSalario() de la clase 'Empleados'
        return sueldoBase= 999;
        }
    
    public int Adicional() {
        return nivelExperiencia = 2;
        }

    @Override
    public String toString() {
        return nivelExperiencia + " en áreas afines";
    }

}
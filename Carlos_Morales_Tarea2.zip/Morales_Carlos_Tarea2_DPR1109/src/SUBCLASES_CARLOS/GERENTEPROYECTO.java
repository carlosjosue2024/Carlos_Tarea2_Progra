package SUBCLASES_CARLOS;

import CLASEMAYOR.EMPLEADOS;

public class GERENTEPROYECTO extends EMPLEADOS{
    private int AniosDeServ;                                                    
    
    //Constructor clase hija 'Analista' 

    public GERENTEPROYECTO(int AniosDeServ, String nombre, int edad, String proyectoAsignado, double salario, String departamento) {
        super(nombre, edad, proyectoAsignado, salario, departamento);
        this.AniosDeServ = AniosDeServ;
    }


    public int getAniosDeServ() {
        return AniosDeServ;
    }

    @Override
    public double CalcularSalario() {                                           
        return sueldoBase = 1200.50;
        }
    
    public int Adicional() {
        return AniosDeServ = 2;
        }

    @Override
    public String toString() {
        return AniosDeServ + " años de servicio en la empresa";
    }

}
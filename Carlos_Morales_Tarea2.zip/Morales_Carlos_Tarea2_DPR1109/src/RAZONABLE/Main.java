package RAZONABLE;

import GUI.INTERFAZ;


public class Main {

    //Código que permite la ejecución de la clase GUI 'INTERFAZ'  y visibilidad en pantalla
        public static void Main(String[] args) {                                
        INTERFAZ panta = new INTERFAZ();
        panta.setVisible(true);
        panta.setLocationRelativeTo(null);
        
    }
}

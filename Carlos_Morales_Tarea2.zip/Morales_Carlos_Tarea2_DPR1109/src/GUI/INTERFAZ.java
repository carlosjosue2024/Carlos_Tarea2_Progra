package GUI;

//Importación de las subclases o clases hijas de 'Empleados'
import SUBCLASES_CARLOS.ANALISTA;
import SUBCLASES_CARLOS.GERENTEPROYECTO;
import SUBCLASES_CARLOS.DESARROLLO;
import SUBCLASES_CARLOS.DISEÑO;
//Librerías para la tabla y autollenado de las Textbox
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;

public class INTERFAZ extends javax.swing.JFrame {
DefaultTableModel dt = new DefaultTableModel();

    public INTERFAZ() {
        initComponents();
        
        //Asignación del título de las columnas de la tabla
        String ids [] = {"Nombre","Edad","Proyecto Asignado","Salario","Departamento","Indispensable"};
        
        dt.setColumnIdentifiers(ids);
        jTable1.setModel(dt);
        
        
        // Agregar el ListSelectionListener al JTableProducto
        jTable1.getSelectionModel().addListSelectionListener((ListSelectionEvent evt) -> {
            // Verificar si la selección de la fila ha terminado
            if (!evt.getValueIsAdjusting()) {
                // Obtener la fila seleccionada
                int filaSeleccionada = jTable1.getSelectedRow();
                
                // Verificar si hay una fila seleccionada
                if (filaSeleccionada != -1) {
                    // Obtener los datos de la fila seleccionada
                    Object nombre = jTable1.getValueAt(filaSeleccionada, 0);
                    Object edad = jTable1.getValueAt(filaSeleccionada, 1);
                    Object proyectoAsignado = jTable1.getValueAt(filaSeleccionada, 2);
                    
                    // Mostrar los datos en los campos de texto
                    jTextFieldNom.setText(nombre.toString());
                    jTextFieldEdad.setText(edad.toString());
                    jTextFieldProy.setText(proyectoAsignado.toString());
                }
            }
        });
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        AgregarButton = new javax.swing.JButton();
        EditarButton = new javax.swing.JButton();
        EliminarButton = new javax.swing.JButton();
        LimpiarButton = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextFieldProy = new javax.swing.JTextField();
        jTextFieldNom = new javax.swing.JTextField();
        jTextFieldEdad = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        FONDOUES = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6"
            }
        ));
        jTable1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, 630, 190));

        AgregarButton.setText("Adicionar");
        AgregarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarButtonActionPerformed(evt);
            }
        });
        jPanel1.add(AgregarButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 210, 100, 30));

        EditarButton.setText("Corregir ");
        EditarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditarButtonActionPerformed(evt);
            }
        });
        jPanel1.add(EditarButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 210, 100, 30));

        EliminarButton.setText("Suprimir");
        EliminarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarButtonActionPerformed(evt);
            }
        });
        jPanel1.add(EliminarButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 210, 100, 30));

        LimpiarButton.setText("Limpiar");
        LimpiarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LimpiarButtonActionPerformed(evt);
            }
        });
        jPanel1.add(LimpiarButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 210, 100, 30));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("\"SISTEMA DE GESTIÓN DE EMPLEADOS DE UNA EMPRESA TECNOLOGICA\"");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 680, 20));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("departamento");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 150, 130, -1));

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("nombre completo ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 130, 30));

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("edad");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 90, 130, 30));

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("proyecto asignado");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 130, 30));

        jTextFieldProy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldProyActionPerformed(evt);
            }
        });
        jPanel1.add(jTextFieldProy, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 140, 180, 30));
        jPanel1.add(jTextFieldNom, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, 180, 30));
        jPanel1.add(jTextFieldEdad, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 90, 180, 30));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona:", "Desarrollo", "Diseño", "Analista", "Gerente" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 140, 180, 30));

        FONDOUES.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        FONDOUES.setIcon(new javax.swing.ImageIcon(getClass().getResource("/GUI/Proyecto nuevo2.png"))); // NOI18N
        FONDOUES.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(FONDOUES, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, -40, 550, 520));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AgregarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarButtonActionPerformed
        
        //Inicialización de la verificación usando Try-Catch, permite evitar errores al ingresar los datos
        try{
        
        String nombre = (jTextFieldNom.getText());                              //Asignación de la variable nombre y proyectoAsignado a los valores de las TextBox
        String proyectoAsignado = (jTextFieldProy.getText());
        if ((nombre.equals("")) || (proyectoAsignado.equals(""))){              //Verifica que no hayan datos vacíos en las TextBox
            javax.swing.JOptionPane.showMessageDialog(this, "No pueden haber campos vacíos", "ERROR", javax.swing.JOptionPane.ERROR_MESSAGE); //Mensaje de error, al ingresar un valor menor o igual a cero.
            return;
            }
        int edad = Integer.parseInt(jTextFieldEdad.getText());
        if ((edad<18) || (edad>75)){                                                   
            javax.swing.JOptionPane.showMessageDialog(this, "Ingrese una edad válida (18 a 75 años)", "ERROR", javax.swing.JOptionPane.ERROR_MESSAGE); //Mensaje de error, al ingresar un valor menor o igual a cero.
            return;
            }
        //Si llega hasta acá, significa que el dato de la edad es un entero válido, en edad laborable
        
        String departamento = (String)jComboBox1.getSelectedItem(); 
            if (departamento.equals("Selecciona:")){                            //Validación que permite que el departamento no esté vacío
        javax.swing.JOptionPane.showMessageDialog(this, "Ingrese un departamento válido", "ERROR", javax.swing.JOptionPane.ERROR_MESSAGE); //Mensaje de error, al ingresar un valor menor o igual a cero.
        return;
        }
            /*Switch case que evalúa el departamento y según sea el caso, manda a llamar
            los datos de las clases hijas, asignándolas a través de instancias de clase.
            A estas se les asigna parámetros estándar, pero serán sobreescritos posteriormente. 
            */            
            DESARROLLO d1 = new DESARROLLO(2, "Walter", 27, "Tarea 2", 2.99f, "Desarrollador");
            DISEÑO d2 = new DISEÑO(2, "Walter", 27, "Tarea 2", 2.99f, "Diseñador");
            ANALISTA d3 = new ANALISTA(2, "Walter", 27, "Tarea 2", 2.99f, "Analista");
            GERENTEPROYECTO d4 = new GERENTEPROYECTO(2, "Walter", 27, "Tarea 2", 2.99f, "Analista");
            
            switch (departamento) {
                case "Desarrollo" -> {
                    
                    double Salario = d1.CalcularSalario();                      //d1 llama los valores de la clase Desarrollador y los asigna en una nueva fila
                    int OTRO = d1.Adicional();
                    dt.addRow(new Object [] {nombre, edad, proyectoAsignado,"$"+Salario,departamento,OTRO+" años de experiencia"});
                    //return;
                }

                case "Diseño" -> {
                    
                    double Salario = d2.CalcularSalario();                      //d2 llama los valores de la clase Diseñador y los asigna en una nueva fila
                    int OTRO = d2.Adicional();
                    dt.addRow(new Object [] {nombre, edad, proyectoAsignado,"$"+Salario,departamento,OTRO+" Programas de diseño"});
                    //return;
                }
                case "Analista" -> {
                    
                    double Salario = d3.CalcularSalario();                      //d3 llama los valores de la clase Analista y los asigna en una nueva fila
                    int OTRO = d3.Adicional();
                    dt.addRow(new Object [] {nombre, edad, proyectoAsignado,"$"+Salario,departamento,OTRO+" años en áreas afines"});
                    //return;
                }
                case "Gerente" -> {
                    
                    double Salario = d4.CalcularSalario();                      //d4 llama los valores de la clase GerenteProyecto y los asigna en una nueva fila
                    int OTRO = d4.Adicional();
                    dt.addRow(new Object [] {nombre, edad, proyectoAsignado,"$"+Salario,departamento,OTRO+" años de servicio en la empresa"});
                    //return;
                }
       case "Selecciona:" -> javax.swing.JOptionPane.showMessageDialog(this, "Ingrese un departamento válido", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
                default -> {                                                    //Valor default
                }
            }
            /*Desarrollo    Diseño  Analista    Gerente*/        
                    
        }catch(NumberFormatException ex){                                       //Catch con el error posible
            javax.swing.JOptionPane.showMessageDialog(this, "Ingrese un valor válido", "ERROR", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
        //Si hay error, setea todas las casillas en blanco
        jTextFieldNom.setText("");                                              
        jTextFieldEdad.setText("");
        jTextFieldProy.setText("");
        jComboBox1.setSelectedItem("Selecciona:");
    }//GEN-LAST:event_AgregarButtonActionPerformed

    private void EliminarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarButtonActionPerformed
        int fila = jTable1.getSelectedRow();
        
        if(fila == -1){                                                         //Verificación que chequea que la fila a eliminar esté seleccionada
            javax.swing.JOptionPane.showMessageDialog(this, "Por favor seleccione una fila.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        return;
        }
        
        dt.removeRow(jTable1.getSelectedRow());                                 //Si lo está, elimina los datos
    }//GEN-LAST:event_EliminarButtonActionPerformed

    private void EditarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditarButtonActionPerformed
        
        int fila = jTable1.getSelectedRow();
        
        if(fila == -1){                                                         //Verifica que la fila esté seleccionada antes de eliminar datos
            javax.swing.JOptionPane.showMessageDialog(this, "Por favor seleccione una fila.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
        return;
        }
        
        try{
            String nombre = (jTextFieldNom.getText());
            String proyectoAsignado = (jTextFieldProy.getText());
            if ((nombre.equals("")) || (proyectoAsignado.equals(""))){                                                   
                javax.swing.JOptionPane.showMessageDialog(this, "No pueden haber campos vacíos", "ERROR", javax.swing.JOptionPane.ERROR_MESSAGE); //Mensaje de error, al ingresar un valor menor o igual a cero.
                return;
                }
            
            int edad = Integer.parseInt(jTextFieldEdad.getText());
            //Si llega hasta acá, significa que el dato es un entero válido
            if ((edad<18) || (edad>75)){                                                   
            javax.swing.JOptionPane.showMessageDialog(this, "Ingrese una edad válida (18 a 75 años)", "ERROR", javax.swing.JOptionPane.ERROR_MESSAGE); //Mensaje de error, al ingresar un valor menor o igual a cero.
            return;
            }
            String departamento = (String)jComboBox1.getSelectedItem();         //Validación que permite que el departamento no esté vacío
            if (departamento.equals("Selecciona:")){
                javax.swing.JOptionPane.showMessageDialog(this, "Ingrese un departamento válido", "ERROR", javax.swing.JOptionPane.ERROR_MESSAGE); //Mensaje de error, al ingresar un valor menor o igual a cero.
                return;
            }
            
            //Switch case que evalúa el departamento y según sea el caso, manda a llamar 
            //los datos de las clases hijas, asignándolas a través de instancias de clase.
            DESARROLLO d1 = new DESARROLLO(2, "Walter", 27, "Tarea 2", 2.99f, "Desarrollador");
            
            DISEÑO d2 = new DISEÑO(2, "Walter", 27, "Tarea 2", 2.99f, "Diseñador");
            
            ANALISTA d3 = new ANALISTA(2, "Walter", 27, "Tarea 2", 2.99f, "Analista");
            
            GERENTEPROYECTO d4 = new GERENTEPROYECTO(2, "Walter", 27, "Tarea 2", 2.99f, "Analista");
            
            switch (departamento) {
                case "Desarrollo" -> {
                //d1 llama los valores de la clase Analista y los asigna en la fila y casilla seleccionada  
                    double Salario = d1.CalcularSalario();
                    int OTRO = d1.Adicional();
                        dt.setValueAt(jTextFieldNom.getText(), jTable1.getSelectedRow(), 0);
                        dt.setValueAt(jTextFieldEdad.getText(), jTable1.getSelectedRow(), 1);
                        dt.setValueAt(jTextFieldProy.getText(), jTable1.getSelectedRow(), 2);
                        dt.setValueAt("$"+Salario, jTable1.getSelectedRow(), 3);
                        dt.setValueAt(jComboBox1.getSelectedItem(), jTable1.getSelectedRow(), 4);
                        dt.setValueAt(OTRO+" años de experiencia", jTable1.getSelectedRow(), 5);
                    //return;
                }

                case "Diseño" -> {
                //d2 llama los valores de la clase Analista y los asigna en la fila y casilla seleccionada    
                    double Salario = d2.CalcularSalario();
                    int OTRO = d2.Adicional();
                        dt.setValueAt(jTextFieldNom.getText(), jTable1.getSelectedRow(), 0);
                        dt.setValueAt(jTextFieldEdad.getText(), jTable1.getSelectedRow(), 1);
                        dt.setValueAt(jTextFieldProy.getText(), jTable1.getSelectedRow(), 2);
                        dt.setValueAt("$"+Salario, jTable1.getSelectedRow(), 3);
                        dt.setValueAt(jComboBox1.getSelectedItem(), jTable1.getSelectedRow(), 4);
                        dt.setValueAt(OTRO+" Programas de diseño", jTable1.getSelectedRow(), 5);
                    //return;
                }
                case "Analista" -> {                                            
                //d3 llama los valores de la clase Analista y los asigna en la fila y casilla seleccionada  
                    double Salario = d3.CalcularSalario();
                    int OTRO = d3.Adicional();
                        dt.setValueAt(jTextFieldNom.getText(), jTable1.getSelectedRow(), 0);
                        dt.setValueAt(jTextFieldEdad.getText(), jTable1.getSelectedRow(), 1);
                        dt.setValueAt(jTextFieldProy.getText(), jTable1.getSelectedRow(), 2);
                        dt.setValueAt("$"+Salario, jTable1.getSelectedRow(), 3);
                        dt.setValueAt(jComboBox1.getSelectedItem(), jTable1.getSelectedRow(), 4);
                        dt.setValueAt(OTRO+" años en áreas afines", jTable1.getSelectedRow(), 5);
                    //return;
                }
                case "Gerente" -> {
                //d4 llama los valores de la clase Analista y los asigna en la fila y casilla seleccionada  
                    double Salario = d4.CalcularSalario();
                    int OTRO = d4.Adicional();
                        dt.setValueAt(jTextFieldNom.getText(), jTable1.getSelectedRow(), 0);
                        dt.setValueAt(jTextFieldEdad.getText(), jTable1.getSelectedRow(), 1);
                        dt.setValueAt(jTextFieldProy.getText(), jTable1.getSelectedRow(), 2);
                        dt.setValueAt("$"+Salario, jTable1.getSelectedRow(), 3);
                        dt.setValueAt(jComboBox1.getSelectedItem(), jTable1.getSelectedRow(), 4);
                        dt.setValueAt(OTRO+" años de servicio en la empresa", jTable1.getSelectedRow(), 5);
                    //return;
                }
       case "Selecciona:" -> javax.swing.JOptionPane.showMessageDialog(this, "Ingrese un departamento válido", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
                default -> {                                                    //Valor estándar
                }
            }
            /*Desarrollo    Diseño  Analista    Gerente*/        
        
        }catch(NumberFormatException ex){  
            javax.swing.JOptionPane.showMessageDialog(this, "Ingrese un valor válido", "ERROR", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
        //Si hay error, setea todas las casillas en blanco
        jTextFieldNom.setText("");
        jTextFieldEdad.setText("");
        jTextFieldProy.setText("");
        jComboBox1.setSelectedItem("Selecciona:");
    }//GEN-LAST:event_EditarButtonActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed

    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void LimpiarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LimpiarButtonActionPerformed
        
        //Permite limpiar las casillas y setearlas en blanco
        jTextFieldNom.setText("");
        jTextFieldEdad.setText("");
        jTextFieldProy.setText("");
        jComboBox1.setSelectedItem("Selecciona:");
    }//GEN-LAST:event_LimpiarButtonActionPerformed

    private void jTextFieldProyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldProyActionPerformed
        //Sí
    }//GEN-LAST:event_jTextFieldProyActionPerformed
        //No

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AgregarButton;
    private javax.swing.JButton EditarButton;
    private javax.swing.JButton EliminarButton;
    private javax.swing.JLabel FONDOUES;
    private javax.swing.JButton LimpiarButton;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextFieldEdad;
    private javax.swing.JTextField jTextFieldNom;
    private javax.swing.JTextField jTextFieldProy;
    // End of variables declaration//GEN-END:variables
}

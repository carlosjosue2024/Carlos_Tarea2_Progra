package SUBCLASES_CARLOS;

import CLASEMAYOR.EMPLEADOS;

public class DESARROLLO extends EMPLEADOS{
    private int nivelExperiencia;                                               
    
    //Constructor clase hija 'Desarrollador'

    public DESARROLLO(int nivelExperiencia, String nombre, int edad, String proyectoAsignado, double salario, String departamento) {
        super(nombre, edad, proyectoAsignado, salario, departamento);
        this.nivelExperiencia = nivelExperiencia;
    }


    public int getNivelExperiencia() {
        return nivelExperiencia;
    }

    @Override
    public double CalcularSalario() {                                           
        return sueldoBase = 500.00;
        }
    
    public int Adicional() {
        return nivelExperiencia = 5;
        }

    @Override
    public String toString() {
        return nivelExperiencia + " Años de experiencia";
    }
}